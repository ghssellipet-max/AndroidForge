# Monopoly Dice Pro — AndroidForge Ready

This project is the polished WebView-based Android version matching the supplied Monopoly Dice Pro preview.

## Important
- This project intentionally uses **no AndroidX dependencies**.
- It loads the complete UI from `app/src/main/assets/index.html`.
- It supports dice rolling, player switching, history, board/heatmap, statistics, and CSV export.
- Build with Android Gradle Plugin 8.5.2 / compileSdk 34 / Java 17.

## AndroidForge
Upload this ZIP/project to your AndroidForge repository and run the normal Android build workflow.
The expected APK should be the polished Monopoly Dice Pro UI, not the old simple native UI.

## Local build
Run:
    gradle assembleDebug
or with a Gradle wrapper:
    ./gradlew assembleDebug

APK output:
    app/build/outputs/apk/debug/app-debug.apk
