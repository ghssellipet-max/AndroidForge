# Monopoly Dice Pro - no custom ProGuard rules required.
