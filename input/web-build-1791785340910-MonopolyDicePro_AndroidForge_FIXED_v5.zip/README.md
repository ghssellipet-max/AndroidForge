# Monopoly Dice Pro COMPLETE v4

AndroidForge-ready project. Replaces the previous incomplete UI script with connected dice, 40-square board, player management, statistics, roll history, CSV/JSON export, undo, clear and local game persistence.

No AndroidX dependencies. Android Gradle Plugin 8.5.2, compileSdk 34, Java 17.

Build via AndroidForge using the input-directory ZIP workflow.
